﻿using System.Net.Sockets;
using System.Net;
using System.Text;

namespace UdpChat
{
    internal class Program
    {
        private static IPAddress? _IPAddress = default;
        private static IPEndPoint _Stub { get; set; } = new IPEndPoint(IPAddress.Any , 0);

        private static IPEndPoint? _Сompanion = default;
        private static IPEndPoint? _BindPoint = default;
        private static int? _ApplicationPort = default;
        private static int? _ServerPort = default;
        private static Byte[] _Buffer { get; set; } = new Byte[8192];

        static void Main(string[] args)
        {
            try
            {
                using (Socket _Socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
                {
                    Console.WriteLine("Введите IP адрес");
                    _IPAddress = IPAddress.Parse(Console.ReadLine());
                    Console.WriteLine("Введите порт сервера (порт для подключеия к другому пользователю)");
                    _ApplicationPort = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Введите порт сервера (порт для принятия сообщений)");
                    _ServerPort = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("----------можно-разговаривать----------");

                    _BindPoint = new IPEndPoint(_IPAddress , _ServerPort.Value);

                    Task.Factory.StartNew(async() => {

                        _Socket.Bind(_BindPoint);

                        while(true) 
                        {
                           SocketReceiveFromResult _res = await _Socket.ReceiveFromAsync(_Buffer, _Stub);
                             Console.WriteLine(Encoding.UTF8.GetString(_Buffer , 0 , _res.ReceivedBytes));
                        }
                    });

                    _Сompanion = new IPEndPoint(_IPAddress , _ApplicationPort.Value);

                    while (true) 
                    {
                        _Socket.SendTo(Encoding.UTF8.GetBytes(Console.ReadLine()) , _Сompanion);
                    }
                }
            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
