﻿using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ConsoleApp2
{
    sealed class Program
    {
        private static object locker = new object();

        private static List<Socket> ConnectedUsers = new List<Socket>();

        static async Task Main(string[] args)
        {
           Console.CursorVisible = false;

           Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp); 
            
                socket.Bind(await Dir.GetBindingIP()); socket.Listen(await Dir.GetCount());

                await Console.Out.WriteLineAsync($"[Успешная инициализация]:[Адрес Сервера]-[{socket.LocalEndPoint}]\n\t[{DateTime.Now}] Ожидание подключений...");

                Task.Run(() => { while (true) {
                        Task.Delay(10000).Wait(); Console.WriteLine($"\t\t[Количиство активных пользователей] {ConnectedUsers.Count}");
                }});

                while (true) 
                {
                    Socket socks = await socket.AcceptAsync();
                    UserConnected(socks);
                    await Console.Out.WriteLineAsync($"[Выделение потока]-{{{socks.RemoteEndPoint}}}");
                }
            
        }
        private static async Task UserConnected(Socket sock) 
        {
            try
            {
                AddToList(sock);
                Byte[] bytes = new Byte[1024];
                int bytesRead;
                StringBuilder stringBuilder = new StringBuilder();
                while (true) 
                {
                    bool MesEnd = false;
                    do
                    {
                        bytesRead = await sock.ReceiveAsync(bytes);
                        stringBuilder.Append(Encoding.Default.GetString(bytes, 0, bytesRead));

                        if (stringBuilder[stringBuilder.Length -1] == '^') 
                        {
                            break;
                        }

                    } while (bytesRead > 0);

                    SendToUsers(stringBuilder.Remove(stringBuilder.Length-1 , 1) , ConnectedUsers , sock);

                    stringBuilder.Clear();

                    if (!sock.Connected) 
                    {
                        await Console.Out.WriteLineAsync($"[Пользователь окончил сеанс] {sock.RemoteEndPoint}");
                        return;
                    }
                }
            }
            catch (SocketException)
            {
                await Console.Out.WriteLineAsync($"\t[Пользователь принудительно окончил сеанс] {sock.RemoteEndPoint}");
            }
            finally 
            {
                RemoveFromList(sock);
                sock.Dispose();
            }
        }

        private static async Task SendToUsers(StringBuilder? builder , List<Socket> conusers , Socket usersocket) 
        {
            string content = builder.ToString().Trim() +"^";
            for (int i = 0; i < conusers.Capacity; i++)
            {
                if (!string.IsNullOrEmpty(content) && conusers[i] != usersocket)
                {
                    conusers[i].SendAsync(Encoding.Default.GetBytes(content));
                }
            }
        } 

        private static void RemoveFromList(Socket endPoint) 
        {
            lock (locker){ ConnectedUsers.Remove(endPoint); }
        }
        private static void AddToList(Socket endPoint) 
        {
            lock (locker) { ConnectedUsers.Add(endPoint); }
        }
    }

    file static class Dir 
    {
        public static async Task<IPEndPoint> GetBindingIP() 
        {
            try
            {
                string ipaddress;
                int port;

                using (FileStream fs = new FileStream("ServerIP.ini" , FileMode.OpenOrCreate , FileAccess.ReadWrite , FileShare.ReadWrite)) 
                {
                    string content = await new StreamReader(fs).ReadToEndAsync();
                    ipaddress = content.Trim();
                }
                using (FileStream fs = new FileStream("ServerPort.ini", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
                {
                    string ntrim = await new StreamReader(fs).ReadToEndAsync();
                    int content = int.Parse(ntrim.Trim());
                    port = content;
                }

                return new IPEndPoint(IPAddress.Parse(ipaddress), port);
            }
            catch(Exception ex)
            {
                await Console.Out.WriteLineAsync(ex.Message);
                return new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8080);
            }
        }
        public static async Task<int> GetCount() 
        {
            using (FileStream fs = new FileStream("MaxUsersCount.ini", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                string ntrim = await new StreamReader(fs).ReadToEndAsync();
                return int.Parse(ntrim.Trim());
            }
        }
    }
}
