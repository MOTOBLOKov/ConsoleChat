﻿using System.Net.Sockets;
using System.Text;

namespace Space
{
    class Program
    {
        private static Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        private static string NickName { get; set; }

        private static async Task Main()
        {
            await Console.Out.WriteLineAsync("[Конфигурация клиента настраивается в корне приложения][NickName][IpAddres][Port]");
            NickName = AppRootHelper.GetNickName();
            await Console.Out.WriteLineAsync($"[Текущая конфигурация]{{NickName:({NickName})-IpAddres:({AppRootHelper.GetIp()})-Port:({AppRootHelper.GetPort()})}}");
            EndPointConfigurator endPoint = new EndPointConfigurator(NickName , AppRootHelper.GetIp() , AppRootHelper.GetPort());
                        Byte[] bytes = new Byte[1024];
 
            await sock.ConnectAsync(endPoint.Ip , endPoint.Port);
            new Thread(AcceptMessages).Start();
            await Console.Out.WriteLineAsync("\t[...Готово!][Можно общаться :) ]");
            while (true) 
            {
               await sock.SendAsync(Encoding.UTF8.GetBytes("["+ NickName +"] "+ Console.ReadLine() + "^"));
               await Task.Delay(1000);
            }
        }

        private async static void AcceptMessages() 
        {
            Byte[] bytes = new Byte[1024];
                   int RequestBytes = default;   
                         StringBuilder stringBuilder = new StringBuilder();

            while (true) 
            {
                do
                {
                    RequestBytes = await sock.ReceiveAsync(bytes);
                    stringBuilder.Append(Encoding.Default.GetString(bytes , 0 , RequestBytes));

                    string content = stringBuilder.ToString();

                    if (content[content.Length-1] == '^') 
                    {
                        stringBuilder.Remove(stringBuilder.Length-1 , 1);
                        break;
                    }


                } while (RequestBytes > 0);

                await Console.Out.WriteLineAsync(stringBuilder.ToString());
                       stringBuilder.Clear();
            }
        }
    }

    record EndPointConfigurator(string NickName , string Ip , int Port);

    static class AppRootHelper 
    {
        public static string GetNickName() 
        {
            using(FileStream fs = new FileStream("NickName.txt" , FileMode.OpenOrCreate , FileAccess.ReadWrite , FileShare.ReadWrite))
            {
                return new StreamReader(fs).ReadToEnd().Trim();
            }
        }  
        public static string GetIp() 
        {
            using (FileStream fs = new FileStream("IpAddres.ini", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                return new StreamReader(fs).ReadToEnd().Trim();
            }
        }
        public static int GetPort() 
        {
            using (FileStream fs = new FileStream("Port.ini", FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                return int.Parse(new StreamReader(fs).ReadToEnd().Trim());
            }
        }
    }
}